<?php 
ini_set('display_errors', 1);
error_reporting(E_ALL);

include("../config/conexiondb.php");

$accion = $_GET['accion'] ?? '';

switch ($accion) {
  case 'listar':
    $sql = "SELECT u.id, u.usuario, u.nombre_completo, u.telefono, u.correo, u.fecha_nacimiento, u.rfc, u.permiso_id, p.nombre AS permiso 
            FROM usuarios u 
            JOIN permisos p ON u.permiso_id = p.id
            WHERE u.estatus = 1";
    $resultado = $conn->query($sql);

    $data = [];
    while ($fila = $resultado->fetch_assoc()) {
      $data[] = $fila;
    }

    echo json_encode(['data' => $data]);
    break;

  case 'obtener':
    $id = $_GET['id'] ?? 0;
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $fila = $resultado->fetch_assoc();
    echo json_encode($fila);
    break;

  case 'guardar':
    $id = $_POST['id'] ?? '';
    $usuario = $_POST['usuario'] ?? '';
    $contrasena = $_POST['contrasena'] ?? '';
    $nombre = $_POST['nombre_completo'] ?? '';
    $permiso_id = $_POST['permiso_id'] ?? 3;
    $telefono = $_POST['telefono'] ?? '';
    $correo = $_POST['correo'] ?? '';
    $fecha_nacimiento = $_POST['fecha_nacimiento'] ?? '';
    $rfc = $_POST['rfc'] ?? '';

    if ($id == '') {
    // NUEVO USUARIO
    $hashedPassword = password_hash($contrasena, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO usuarios (usuario, contrasena, nombre_completo, permiso_id, telefono, correo, fecha_nacimiento, rfc) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssissss", $usuario, $hashedPassword, $nombre, $permiso_id, $telefono, $correo, $fecha_nacimiento, $rfc);
    $stmt->execute();
    echo "Usuario agregado correctamente";
    } else {
        // ACTUALIZACIÓN DE USUARIO
        if (!empty($contrasena)) {
            $hashedPassword = password_hash($contrasena, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE usuarios SET usuario = ?, contrasena = ?, nombre_completo = ?, permiso_id = ?, telefono = ?, correo = ?, fecha_nacimiento = ?, rfc = ? WHERE id = ?");
            $stmt->bind_param("sssissssi", $usuario, $hashedPassword, $nombre, $permiso_id, $telefono, $correo, $fecha_nacimiento, $rfc, $id);
        } else {
            // No se cambia contraseña
            $stmt = $conn->prepare("UPDATE usuarios SET usuario = ?, nombre_completo = ?, permiso_id = ?, telefono = ?, correo = ?, fecha_nacimiento = ?, rfc = ? WHERE id = ?");
            $stmt->bind_param("ssiisssi", $usuario, $nombre, $permiso_id, $telefono, $correo, $fecha_nacimiento, $rfc, $id);
        }
        $stmt->execute();
        echo "Usuario actualizado correctamente";
    }

    break;

  case 'eliminar':
    $id = $_POST['id'] ?? 0;
    $stmt = $conn->prepare("UPDATE usuarios SET estatus = 0 WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    echo "Usuario eliminado correctamente";
    break;

  default:
    echo "Acción no válida";
    break;
}
