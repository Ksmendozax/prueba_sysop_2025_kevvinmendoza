<?php 
session_start();
include("conexiondb.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, usuario, contrasena, nombre_completo, permiso_id FROM usuarios WHERE usuario = ? AND estatus = 1");
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows === 1) {
        $fila = $resultado->fetch_assoc();

        if (password_verify($password, $fila['contrasena'])) {
            $_SESSION['usuario_id'] = $fila['id'];
            $_SESSION['usuario'] = $fila['usuario'];
            $_SESSION['nombre'] = $fila['nombre_completo'];
            $_SESSION['permiso_id'] = $fila['permiso_id'];
            $_SESSION['mostrar_bienvenida'] = true; 

            header("Location: ../../dashboard.php");
            exit;
        } else {
            $_SESSION['error_login'] = "❌ Contraseña incorrecta.";
            header("Location: ../../index.php");
            exit;
        }
    } else {
        $_SESSION['error_login'] = "❌ Usuario no encontrado.";
        header("Location: ../../index.php");
        exit;
    }
}
?>
