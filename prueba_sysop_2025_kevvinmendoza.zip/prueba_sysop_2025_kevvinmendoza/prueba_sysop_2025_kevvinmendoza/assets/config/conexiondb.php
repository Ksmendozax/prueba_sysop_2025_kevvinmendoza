<?php
$host = 'localhost';
$usuario = 'usr_sysop_kevvin';  
$contrasena = 'pwd_secret_sysop_2025';  
$base_datos = 'db_sysop_kevvin';  

$conn = new mysqli($host, $usuario, $contrasena, $base_datos);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$conn->set_charset("utf8");
?>
