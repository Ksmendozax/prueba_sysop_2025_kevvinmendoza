<?php if (!isset($_SESSION)) session_start(); ?>
<?php $permiso_id = $_SESSION['permiso_id'] ?? 0; ?>

<style>
  body {
    overflow-x: hidden;
  }

  .sidebar {
    width: 80px;
    height: 100vh;
    position: fixed;
    background-color: #000033;
    transition: width 0.3s;
    z-index: 1000;
  }

  .sidebar .nav-link {
    color: #fff;
    text-align: center;
    padding: 20px 0;
    position: relative;
  }

  .sidebar .nav-link:hover {
    background-color: #001144;
  }

  .sidebar .nav-link:hover::after {
    content: attr(data-title);
    position: absolute;
    left: 100%;
    top: 50%;
    transform: translateY(-50%);
    background-color: #000033;
    color: #fff;
    padding: 5px 10px;
    border-radius: 5px;
    white-space: nowrap;
  }

  .content {
    margin-left: 100px;
    padding: 30px;
  }
   .contenido {
      margin-left: 80px;
      padding: 2rem;
    }

  /* Responsive - para pantallas pequeñas */
  @media (max-width: 768px) {
    .sidebar {
      flex-direction: row !important;
      width: 100%;
      height: auto;
      position: static;
    }

    .sidebar .nav-link {
      padding: 15px;
      flex-grow: 1;
    }

    .contenido {
      margin-left: 0px;
      padding: 2rem;

    .sidebar .nav-link:hover::after {
      display: none;
    }
    #mensaje {
    position: fixed;
    top: 1rem;
    right: 1rem;
    z-index: 1055; 
    max-width: 350px;
}
  }

</style>

<!-- Sidebar -->
<div class="sidebar d-flex flex-column flex-md-column flex-sm-row align-items-center justify-content-center">
  <a href="dashboard.php" class="nav-link" data-title="Inicio"><i class="fas fa-home fa-lg"></i></a>

  <?php if ($permiso_id == 1): ?>
    <a href="admin.php" class="nav-link" data-title="Administración"><i class="fas fa-users-cog fa-lg"></i></a>
  <?php endif; ?>

  <a href="assets/config/logout.php" class="nav-link mt-auto" data-title="Cerrar sesión"> <i class="fas fa-sign-out-alt fa-lg"></i></a>

</div>
