<?php
session_start();
$permiso_id = $_SESSION['permiso_id'] ?? 0;
if ($permiso_id != 1) {
  header("Location: dashboard.php");
  exit;
}
include("assets/config/conexiondb.php");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Administración de Usuarios</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta content="Premium Multipurpose Admin &amp; Dashboard Template" name="description">
  <meta content="Themesbrand" name="author">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <!-- Sidebar -->
  <?php include("assets/config/sidebar.php"); ?>
  <!-- /Sidebar -->

<!-- Contenido -->
<div class="contenido">
  <div class="container-fluid">
    <h2 class="mb-4"><i class="fas fa-users-cog"></i> Administración de Usuarios</h2>
    
    <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modalUsuario" onclick="limpiarFormulario()">Agregar Usuario</button>

    <table id="tablaUsuarios" class="table table-bordered table-striped"> 
        <thead>
          <tr>
            <th>ID</th>
            <th>Usuario</th>
            <th>Nombre</th>
            <th>Permiso</th>
            <th>Teléfono</th>
            <th>Correo</th>
            <th>RFC</th>
            <th>Acciones</th>
          </tr>
        </thead>
      </table>

  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="modalUsuario" tabindex="-1">
  <div class="modal-dialog">
    <form id="formUsuario">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Usuario</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="id" id="id">
          <div class="mb-3">
            <label>Usuario</label>
            <input type="text" name="usuario" id="usuario" class="form-control" required>
          </div>
          <div class="input-group">
            <input type="password" class="form-control" id="contrasena" name="contrasena">
            <button class="btn btn-outline-secondary" type="button" id="togglePassword">
              <i class="fas fa-eye" id="iconoPassword"></i>
            </button>
          </div>

          <div class="mb-3">
            <label>Nombre Completo</label>
            <input type="text" name="nombre_completo" id="nombre_completo" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Teléfono</label>
            <input type="tel" name="telefono" id="telefono" class="form-control" required pattern="[0-9]{10}" maxlength="10">
          </div>
          <div class="mb-3">
            <label>Correo Electrónico</label>
            <input type="email" name="correo" id="correo" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>Fecha de Nacimiento</label>
            <input type="date" name="fecha_nacimiento" id="fecha_nacimiento" class="form-control" required>
          </div>
          <div class="mb-3">
            <label>RFC</label>
            <input type="text" name="rfc" id="rfc" class="form-control" maxlength="13" oninput="this.value = this.value.toUpperCase();" required pattern="[A-ZÑ&]{3,4}[0-9]{6}[A-Z0-9]{3}">
          </div>


          <div class="mb-3">
            <label>Permiso</label>
            <select name="permiso_id" id="permiso_id" class="form-select" required>
              <option value="1">Administrador</option>
              <option value="2">Empleado</option>
              <option value="3">Ejecutivo</option>
            </select>
          </div>
        </div>
        <div class="modal-footer">
          <!-- Botón Cancelar -->
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <!-- Botón Guardar -->
        <button type="submit" class="btn btn-primary">Guardar</button>

        </div>
      </div>
    </form>
  </div>
</div>
<div id="mensaje" class="mt-2"></div>
<!-- Modal Confirmar Eliminación -->
<div class="modal fade" id="modalConfirmarEliminar" tabindex="-1" aria-labelledby="modalConfirmarEliminarLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalConfirmarEliminarLabel"><i class="fas fa-exclamation-triangle text-warning me-2"></i> Confirmar eliminación</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        ¿Estás seguro de eliminar este usuario?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-danger" id="btnEliminarConfirmar">Eliminar</button>
      </div>
    </div>
  </div>
</div>


<!-- JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<!-- SweetAlert2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
  let tabla;

  $(document).ready(function () {
    tabla = $('#tablaUsuarios').DataTable({
      ajax: 'assets/acciones/usuarios.php?accion=listar',
      columns: [
      { data: 'id' },
      { data: 'usuario' },
      { data: 'nombre_completo' },
      { data: 'permiso' },
      { data: 'telefono' },
      { data: 'correo' },
      { data: 'rfc' },
      {
        data: null,
        render: function (data) {
          return `
            <button class="btn btn-warning btn-sm" onclick="editarUsuario(${data.id})"><i class="fas fa-edit"></i></button>
            <button class="btn btn-danger btn-sm" onclick="eliminarUsuario(${data.id})"><i class="fas fa-trash-alt"></i></button>
          `;
        }
      }
    ]

    });

    // Evento para guardar usuario (crear o actualizar)
    $('#formUsuario').on('submit', function (e) {
      e.preventDefault();
      $.ajax({
        url: 'assets/acciones/usuarios.php?accion=guardar',
        method: 'POST',
        data: $(this).serialize(),
        success: function (respuesta) {
          mostrarMensaje(respuesta, 'success');
          $('#formUsuario')[0].reset();
          $('#modalUsuario').modal('hide');
          tabla.ajax.reload();
        },
        error: function () {
          mostrarMensaje('Ocurrió un error al guardar.', 'error');
        }
      });
    });
  });

  function editarUsuario(id) {
  $.get('assets/acciones/usuarios.php?accion=obtener&id=' + id, function (data) {
    const user = JSON.parse(data);
    $('#id').val(user.id);
    $('#usuario').val(user.usuario);
    $('#contrasena').val(''); // Dejar vacío
    $('#nombre_completo').val(user.nombre_completo);
    $('#permiso_id').val(user.permiso_id);
    $('#telefono').val(user.telefono);
    $('#correo').val(user.correo);
    $('#fecha_nacimiento').val(user.fecha_nacimiento);
    $('#rfc').val(user.rfc);

    $('#modalUsuario').modal('show');
  });
}


  let usuarioIdAEliminar = null;

  function eliminarUsuario(id) {
    usuarioIdAEliminar = id;
    const modalEliminar = new bootstrap.Modal(document.getElementById('modalConfirmarEliminar'));
    modalEliminar.show();
  }

  $('#btnEliminarConfirmar').on('click', function () {
    if (usuarioIdAEliminar) {
      $.post('assets/acciones/usuarios.php?accion=eliminar', { id: usuarioIdAEliminar }, function (res) {
        mostrarMensaje(res, 'success');
        tabla.ajax.reload();
        usuarioIdAEliminar = null;
        bootstrap.Modal.getInstance(document.getElementById('modalConfirmarEliminar')).hide();
      });
    }
  });

  function limpiarFormulario() {
    $('#formUsuario')[0].reset();
    $('#id').val('');
  }

  function mostrarMensaje(mensaje, tipo = 'success') {
    Swal.fire({
      icon: tipo,
      title: mensaje,
      showConfirmButton: false,
      timer: 2500
    });
  }

  document.getElementById('togglePassword').addEventListener('click', function () {
    const input = document.getElementById('contrasena');
    const icono = document.getElementById('iconoPassword');
    if (input.type === "password") {
      input.type = "text";
      icono.classList.remove('fa-eye');
      icono.classList.add('fa-eye-slash');
    } else {
      input.type = "password";
      icono.classList.remove('fa-eye-slash');
      icono.classList.add('fa-eye');
    }
  });
</script>


</body>
</html>
