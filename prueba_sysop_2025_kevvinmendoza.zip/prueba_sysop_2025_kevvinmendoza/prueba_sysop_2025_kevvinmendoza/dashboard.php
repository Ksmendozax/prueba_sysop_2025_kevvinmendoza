<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit;
}

$nombre = $_SESSION['nombre'];
$permiso_id = $_SESSION['permiso_id'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Dashboard | SysOp</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
</head>
<body>

<?php include("assets/config/sidebar.php"); ?>

<div class="container py-5">
    <h1 class="text-center mb-4"><i class="fas fa-tachometer-alt"></i> Bienvenido al Panel Principal</h1>

    <!-- Mostrar solo el nombre si no es administrador -->
    <?php if ($permiso_id != 1): ?>
        <div class="alert alert-info text-center">
            Hola <strong><?php echo htmlspecialchars($nombre); ?></strong>, gracias por iniciar sesión.
        </div>
    <?php else: ?>
        <!-- Administrador ve opciones completas -->
        <div class="text-center">
            <p>Hola <strong><?php echo htmlspecialchars($nombre); ?></strong>, tienes acceso completo al sistema.</p>
            <a href="admin.php" class="btn btn-primary"><i class="fas fa-users-cog"></i> Ir a administración</a>
        </div>
    <?php endif; ?>
</div>

<!-- Modal Bienvenida -->
<div class="modal fade" id="bienvenidaModal" tabindex="-1" aria-labelledby="bienvenidaModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content text-center">
      <div class="modal-header">
        <h5 class="modal-title w-100" id="bienvenidaModalLabel">¡Bienvenido!</h5>
      </div>
      <div class="modal-body">
        <i class="fas fa-user-circle fa-3x mb-3 text-primary"></i>
        <p class="fs-5">Hola, <strong><?php echo htmlspecialchars($nombre); ?></strong>. Has iniciado sesión correctamente.</p>
      </div>
      <div class="modal-footer justify-content-center">
        <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Aceptar</button>
      </div>
    </div>
  </div>
</div>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<?php if (isset($_SESSION['mostrar_bienvenida']) && $_SESSION['mostrar_bienvenida']): ?>
<script>
  document.addEventListener("DOMContentLoaded", function () {
    var myModal = new bootstrap.Modal(document.getElementById('bienvenidaModal'));
    myModal.show();
  });
</script>
<?php unset($_SESSION['mostrar_bienvenida']); ?>
<?php endif; ?>

</body>
</html>
