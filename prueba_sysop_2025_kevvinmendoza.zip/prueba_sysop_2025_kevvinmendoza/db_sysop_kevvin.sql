-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: db_sysop_kevvin
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `directorio`
--

DROP TABLE IF EXISTS `directorio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `directorio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `apellido_paterno` varchar(50) NOT NULL,
  `apellido_materno` varchar(50) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `correo_electronico` varchar(100) DEFAULT NULL,
  `ciudad` varchar(50) DEFAULT NULL,
  `estado` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `directorio`
--

LOCK TABLES `directorio` WRITE;
/*!40000 ALTER TABLE `directorio` DISABLE KEYS */;
INSERT INTO `directorio` VALUES (2,'juan','perez','rivera','8111223221','ejemplo@ejemplo.com','Monterrey','Nuevo Leon'),(3,'ejmplo','ejemplo','ejemplo','1234567890','user@user.com','Baja California','Mexicali');
/*!40000 ALTER TABLE `directorio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permisos`
--

DROP TABLE IF EXISTS `permisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permisos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permisos`
--

LOCK TABLES `permisos` WRITE;
/*!40000 ALTER TABLE `permisos` DISABLE KEYS */;
INSERT INTO `permisos` VALUES (1,'Administrador'),(2,'Empleado'),(3,'Ejecutivo');
/*!40000 ALTER TABLE `permisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `nombre_completo` varchar(100) NOT NULL,
  `permiso_id` int(11) NOT NULL,
  `telefono` varchar(15) NOT NULL DEFAULT '81123456',
  `correo` varchar(100) NOT NULL DEFAULT 'ejemp@ejemplo.com',
  `fecha_nacimiento` date NOT NULL DEFAULT '2000-01-01',
  `rfc` varchar(13) NOT NULL DEFAULT 'XXXX000000XXX',
  `estatus` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`),
  KEY `permiso_id` (`permiso_id`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`permiso_id`) REFERENCES `permisos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (6,'mperales','$2y$10$RcdGi3ihYR/I4hNYqzrE0.dr.ykcWPqTiPWd3i.hYPfHxj9cUHy/q','M Perales',2,'81123456','ejemp@ejemplo.com','2000-01-01','XXXX000000XXX',1),(7,'vtobias','$2y$10$Ac4u6NcnHnvgpw7meqYdge5oCmaYsiOanRtmQq0XW0WGdYCCmnIBa','V Tobías',3,'81123456','ejemp@ejemplo.com','2000-01-01','XXXX000000XXX',1),(8,'administerador','$2y$10$0xoNKAf9s.hwlcyNze5WguF/4lQ9Pl26zk5tXmYWLFrZyprTIpNF2','Roberto Espejel García',1,'81123456','ejemp@ejemplo.com','2000-01-01','XXXX000000XXX',1),(9,'ejem','$2y$10$U3pDa0ZDoyCyIBS5VFCsOO1puuxbZVjvPitCiPmWa.LfPEi.YZuFK','Kevvin Mendoza',2,'8127554351','eje@ejem','2025-07-01','MECK000000XXX',0),(10,'SegEje','$2y$10$sIqQjDxNFgh36wame3g1/eQPe9Eb4Otf5soWcD51flXrIH8Zc0AYe','Shahir Mendoza',1,'8282222222','eje@ejem','2025-07-15','MECK000000XXX',1),(11,'sist','$2y$10$.002Hv7YgxUVbRBu/LQumOMimuyYCIwLLsoYmvhvsly.louMp5KW6','Mendoza',3,'2121829182','eje@ejem','2025-07-19','MECK000000XXX',0),(12,'user','$2y$10$JmjSXoBa74fMM2FNEmFQIeda/lQuDL6V/RTOPJHEVPFjWbmtBoe.C','mendoza mendez',3,'2323123123','eje@ejem','2025-07-08','MECK000000XXX',0),(13,'admin','$2y$10$XsO6l0KxTEffPnCXBTASTuYTyawpw.Y23vaRI98FZwlIcbe1PY6x.','Jose Jose',3,'1212312323','eje@ejem','2025-07-20','MECK000000XXX',0),(17,'sxsxasx','$2y$10$7GRAbO7bDS2Dw1lFCeaX1Or1yChVbFHgERziJp6FnTC.cH2Bq2HvW','asdadsa',3,'2121829182','eje@ejem','2025-07-14','MECK000000XXX',0),(21,'qwqwdqw','$2y$10$xNTjpqZK0SEV5ct8dZIXWOfyvVxTdyg8kzgozUwRZQvvDrOxIJSIS','adasdqwd',2,'2121829182','eje@ejem','2025-07-16','MECK000000XXX',0),(22,'assasas','$2y$10$fxI92lHXNgM6e6VjgDaDJeHNSKdJPxDxEkZG2wU8qcsq/Hb5FUFnm','asasas',3,'2121829182','eje@ejem','2025-07-14','MECK000000XXX',0);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-20 15:44:41
